const fs = require('fs')
const chalk = require('chalk')

global.thum = fs.readFileSync("./media/zaki.jpg")

global.autoReadAll = true 

// '6285878313791' ganti nomor kalian '628xxxxxx'
//KiZakiXD ganti nama kalian xxxxz
//Silahkan sesuaikan sendiri ya

// Ganti Sewajarnya
global.owner = ['6289637049604']
global.pengguna = 'EzaTzy'
global.premium = []
global.author = 'EzaTzy'
global.pemilik = ['6289637049604'] 
global.ownernomer = '6289637049604'
global.ownername = 'EzaTzy'
global.botname = 'Eza - MD'
global.tengah = "									"
global.Prefix = 'Multi Prefix'
global.meki = '6289637049604'
global.footer = 'E z a - 𝘔 𝘋'
//Isi Sesuai Namalu Buat Tambah Tqtq
global.namalu = 'Ezatzy' //Ubah nama kalian buat nambahin di tqtq bot
global.footer1 = 'Jangan Spam Bot.'
global.footer2 = 'Jika Menemukan Bug Lapor Ke Owner.'
global.yt = 'https://www.youtube.com/channel/' //Jika tidak ada yt jangan diubah buat promosi owner xixixixi
global.ig = 'https://instagram.com/'
global.gc = 'https://chat.whatsapp.com/' //join ya kadang kadang pada eval bot disitu lumayan dapet fitur baru wkwkwk
global.dana = '00000'
global.gopay = '0000'
global.wame = 'wa.me/6289637049604'
global.email = 'ezatzy24@gmail.com'
global.region = 'Indonesia'
global.link = 'nekopoi.care'
global.sc = 'silit'
global.packname = '"{\nAuthor: KiZakiXD"\n"Bot Number: 6289637049604"\n"Bot Name: Chitanda - MD"\n"Instagram: @iamkizakixd"\n}' 
global.author = '' 
global.sessionName = 'session'
global.prefa = ['#','!','/','']
global.sp = '❑ ' 
global.mess = {
    success: 'Done Your Request',
    admin: 'Fitur Khusus Admin Group!',
    botAdmin: 'Bot Harus Menjadi Admin Terlebih Dahulu!',
    owner: 'Fitur Khusus Owner Bot',
    group: 'Fitur Digunakan Hanya Untuk Group!',
    private: 'Fitur Digunakan Hanya Untuk Private Chat!',
    bot: 'Fitur Khusus Pengguna Nomor Bot',
    wait: 'Loading...',
    error: 'Fitur sedang error!',
        endLimit: 'Limit Harian Anda Telah Habis, Limit Akan Direset Setiap Jam 12',
    wrongFormat: 'Perintah Salah!!\nSertakan Link setelah Command..',
    example1: 'Welcome @user Di Group @subject Jangan Lupa Baca Rules @desc\n\nNote :\n1. @user (Mention User Join)\n2. @subject (Group Name)\n3. @tanggal (Date Now)\n4. @desc (Get Description Group)'
,
    example2: 'Good Bye @user Di Group @subject Jangan Lupa Baca Rules @desc\n\nNote :\n1. @user (Mention User Join)\n2. @subject (Group Name)\n3. @tanggal (Date Now)\n4. @desc (Get Description Group)'    
    
}
    global.limitawal = {
    premium: "Unlimited",
    free: 30,
    monayawal: 1000
}
   global.rpg = {
   darahawal: 100,
   besiawal: 15,
   goldawal: 10,
   emeraldawal: 5,
   umpanawal: 5,
   potionawal: 1
}
global.thumb = fs.readFileSync('./media/zaki.jpg')
global.fakeImg = fs.readFileSync('./media/fake.jpg')

//Ambil dr chika
global.flaming = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=sketch-name&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='
global.fluming = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=fluffy-logo&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='
global.flarun = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=runner-logo&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='
global.flasmurf = 'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=smurfs-logo&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&text='

//Menu
global.ccomannya = `
  「 *Main Menu* 」
 » speedtest
 » ping
 » owner
 » menu
 » delete
 » infochat
 » quoted
 » listpc
 » listonline
  
  「 *Group Menu* 」
 » linkgroup
 » ephemeral [option]
 » setppgc [image]
 » setname [text]
 » setdesc [text]
 » group [option]
 » editinfo [option]
 » add @user
 » kick @user
 » hidetag [text]
 » tagall [text]
 » antilink [on/off]
 » mute [on/off]
 » promote @user
 » demote @user
 » vote [text]
 » devote
 » upvote
 » cekvote
 » hapusvote

  「 *Owner Menu* 」
 » react [emoji]
 » chat [option]
 » join [link]
 » leave
 » block @user
 » setbiobot [text] 
 » unblock @user
 » bcgroup [text]
 » bcall [text]
 » setppbot [image]
 » setexif
  
  「 *Rpg Menu* 」
 » berburu
 » mancing
 » menambang
 » mining
 » heal
 » profile
 » inventory
 » leaderboard
 » buy
 » sell

  「 *Downloader Menu* 」
 » tiktok [url]
 » instagram [url]
 » twitter [url]
 » facebook [url]
 » igstory [query]
 » umma [url]
 » mediafire [url]
 » gitclone [url]
 
  「 *Text Pro Menu* 」
 » textmaker glicth [Text]
 » textmaker glow [Text]
 » flasmurf [Text]
 » flarun [Text]
 » fluming [Text]
 » flaming [Text]
 » lava [Text]
 » neonlight [Text]
 » fabric [Text]
 » glue [Text]
 » luxury [Text]
 » underwater [Text]
 » harrypotter [Text]
 » steel [Text]
 » metallic [Text]
 » graffiti [Text]
 » pencil [Text]
 » sand [Text]
 » magma [Text]
 » joker [Text]
 » sky [Text]
 » matrix [Text]
 » neon [Text]
 » blackpink [Text]
 » thunder [Text]
 » whitebear [Text]
 » hoorror [Text]
 » 8bit [Text]
 » horror [Text]
 » retro [Text]
 » pornhub [Text]
 » juice [Text]
 » batman [Text]
 » multicolor [Text]
 » collwall [Text]
 » cool [Text]
 » wonderful [Text]
 » sketch [Text]
 » skeleton [Text]
 » marvel [Text]
 » foggy [Text]
 » writing [Text]
 » halloween [Text]
 » watercolor [Text]
 » classic [Text]
 » rainbow [Text]
 » sci_fi [Text]
 » christmas [Text]
 » ancient [Text]
 » toxic [Text]

  「 *Stalker Menu* 」
 » ghstalk [query]
 » igstalk [query]
 » ffstalk [query]
 » supersusstalk [query]

  「 *Internet Menu* 」
 » ip [query]
 » iploc [query]
 » ipinfo [query]
 » ssweb [query]
  
  「 *Search Menu* 」
 » play [query]
 » yts [query]
 » google [query]
 » gimage [query]
 » pinterest [query]
 » wallpaper [query]
 » wikimedia [query]
 » ytsearch [query]
 » ringtone [query]
 » stalk [option] [query]
 » webtoons [query]
 » drakor [query]
 » anime [query]
 » character [query]
 » manga [query]

  「 *Random Menu* 」
 » coffe
 » quotesanime
 » couple
 » anime
 » waifu (nsfw)
 » husbu (nsfw)
 » neko (nsfw)
 » shinobu (nsfw)
 » waifus (nsfw)
 » nekos (nsfw)
 » trap (nsfw)
 » blowjob (nsfw)

  「 *Random Anime Menu* 」
 » loli
 » neko
 » waifu
 » shinobu
 » megumin
 » bully
 » cuddle
 » cry
 » hug
 » awoo
 » kiss
 » lick
 » pat
 » smug
 » bonk
 » yeet
 » blush
 » smile
 » wave
 » highfive
 » handhold
 » nom
 » bite
 » glomp
 » slap
 » kill
 » happy
 » wink
 » poke
 » dance
 » cringe

  「 *Fun Menu* 」
 » bagaimanakah
 » kapankah
 » apakah
 » bisakah
 » rate
 » wangy
 » gantengcek
 » cekganteng
 » cantikcek
 » cekcantik
 » sangecek
 » ceksange
 » cekme
 » gaycek
 » cekgay
 » lesbicek
 » halah
 » hilih
 » huluh
 » heleh
 » holoh
 » jadian
 » jodohku
 » delttt
 » tictactoe
 » family100
 » tebak [option]
 » math [mode]
 » suitpvp [@tag]

  「 *Primbon Menu* 」
 » nomorhoki
 » artimimpi
 » artinama
 » ramaljodoh
 » ramaljodohbali
 » suamiistri
 » ramalcinta
 » cocoknama
 » pasangan
 » jadiannikah
 » sifatusaha
 » rezeki
 » pekerjaan
 » nasib
 » penyakit
 » tarot
 » fengshui
 » haribaik
 » harisangar
 » harisial
 » nagahari
 » arahrezeki
 » peruntungan
 » weton
 » karakter
 » keberuntungan
 » memancing
 » masasubur
 » zodiak
 » shio

  「 *Convert Menu* 」
 » toimage
 » removebg
 » sticker
 » emojimix
 » tovideo
 » togif
 » tourl
 » tovn
 » tomp3
 » toaudio
 » ebinary
 » dbinary
 » styletext
 » smeme

  「 *Database Menu* 」
 » setcmd
 » listcmd
 » delcmd
 » lockcmd
 » addmsg
 » listmsg
 » getmsg
 » delmsg

  「 *Anonymous Menu* 」
 » anonymous
 » start
 » next
 » keluar
 » sendkontak

  「 *Islamic Menu* 」
 » iqra
 » hadist
 » alquran
 » juzamma
 » tafsirsurah

  「 *Voice Changer* 」
 » bass
 » blown
 » deep
 » earrape
 » fast
 » fat
 » nightcore
 » reverse
 » robot
 » slow
 » tupai
`
global.sewanya =
'  *» List Sewabot :*\n   _• Sewa Bot 1 Minggu : 7K_\n   _• Sewa Bot 1 Bulan : 15K_\n   _• Sewa Bot 1 Tahun : 30K_'

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})
